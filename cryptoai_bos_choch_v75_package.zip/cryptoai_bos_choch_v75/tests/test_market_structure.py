import unittest,sys
from pathlib import Path; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'source'))
from market_structure import confirmed_structure,structure_bracket

def candles(closes,highs=None,lows=None):
    return [{'time':i*900000,'high':(highs[i] if highs else x+.4),'low':(lows[i] if lows else x-.4),'close':x} for i,x in enumerate(closes)]

class TestStructure(unittest.TestCase):
    def test_bos_only_after_closed_break(self):
        prices=[100,101,102,103,102,101,100,99,98,99,100,101,102,103,104,103,104.5]
        a=candles(prices)
        snap=confirmed_structure(a)
        self.assertEqual(snap['event'], 'BOS')
        self.assertEqual(snap['direction'],'LONG')
        self.assertEqual(snap['bars_since'],0)
        self.assertEqual(confirmed_structure(a[:-1])['bars_since'],1)
        bracket=structure_bracket(snap,'LONG',104.5,.05)
        self.assertIsNotNone(bracket)
        self.assertTrue(bracket['stop']<104.5<bracket['target'])
    def test_choch_and_short_direction(self):
        # Upward BOS, then a confirmed low-side break in the opposite direction.
        prices=[100,101,102,103,102,101,100,99,98,99,100,101,102,103,104,103,104.5,103,102,101,100,99,98,97]
        a=candles(prices)
        s=confirmed_structure(a)
        self.assertEqual(s['direction'],'SHORT')
        self.assertEqual(s['event'],'CHoCH')
        self.assertIsNone(structure_bracket(s,'LONG',97,.02))
        z=structure_bracket(s,'SHORT',97,.03)
        self.assertIsNotNone(z)
        self.assertTrue(z['target']<97<z['stop'])
    def test_reject_stale_and_invalid(self):
        a=candles([100,101,102,103,102,101,100,99,98,99,100,101,102,103,104,103,104.5]);s=confirmed_structure(a)
        self.assertIsNone(structure_bracket(dict(s,bars_since=9),'LONG',104.5,.02))
        self.assertIsNone(structure_bracket(dict(s,protected_swing=10),'LONG',104.5,.02))
        self.assertIsNone(structure_bracket(dict(s,protected_swing=float('nan')),'LONG',104.5,.02))
        self.assertIsNone(confirmed_structure(a[:-1] + [dict(a[-1],time=a[-1]['time']+900000)])['event'])
    def test_closed_pivots_only_no_lookahead(self):
        prices=[100,101,102,103,102,101,100,99,98,99,100,101,102,103,104,103,104.5,103,102,101,100,99,98,97]
        bars=candles(prices)
        for count in range(10,len(bars)+1):
            early=confirmed_structure(bars[:count]);full=confirmed_structure(bars[:count])
            self.assertEqual(early,full)

if __name__=='__main__':unittest.main()

# Forward bid/ask paper execution integration; only exercises synthetic quotes,
# does not imply any live-market TP win probability or validated profitability.
class StructurePaperIntegrationTests(unittest.TestCase):
    def test_structural_long_is_frozen_at_observed_entry_and_audited(self):
        import json,sqlite3
        import execution_paper
        from quality_report import calibration
        from test_v62 import prediction,NOW
        bars=candles([100,101,102,103,102,101,100,99,98,99,100,101,102,103,104,103,104.5])
        structure=confirmed_structure(bars)
        p=prediction()
        p.update(market_structure=structure,risk_atr_pct=.05,execution_quality={'approved':True})
        book={'bid':104.49,'ask':104.50,'bid_qty':20.,'ask_qty':20.,'updated_at':NOW/1000-1}
        db=sqlite3.connect(':memory:')
        try:
            execution_paper.setup(db)
            self.assertTrue(execution_paper.observe(db,'BTCUSDT',p,book,NOW))
            entry,stop,target,audit_text=db.execute('SELECT entry_price,stop_price,target_price,entry_audit FROM executable_paper').fetchone()
            audit=json.loads(audit_text)
            self.assertEqual(audit['bracket_method'],'bos_choch_confirmed_live')
            self.assertLess(stop,entry)
            self.assertGreater(target,entry)
            self.assertAlmostEqual(stop,structure_bracket(structure,'LONG',entry,.05)['stop'])
            self.assertEqual(execution_paper.report(db)['bracket_summary']['bos_choch_confirmed_live']['observed'],1)
            self.assertEqual(calibration(db,NOW)['experimental_structure_excluded'],1)
        finally:db.close()

    def test_missing_or_stale_structure_preserves_frozen_atr(self):
        import json,sqlite3
        import execution_paper
        from test_v62 import prediction,NOW
        p=prediction('LONG');p.update(market_structure={'event':'BOS','direction':'LONG','bars_since':9},execution_quality={'approved':True})
        book={'bid':99.99,'ask':100.01,'bid_qty':10.,'ask_qty':10.,'updated_at':NOW/1000-1}
        db=sqlite3.connect(':memory:')
        try:
            execution_paper.setup(db)
            self.assertTrue(execution_paper.observe(db,'BTCUSDT',p,book,NOW))
            entry,stop,target,audit=db.execute('SELECT entry_price,stop_price,target_price,entry_audit FROM executable_paper').fetchone()
            self.assertEqual(json.loads(audit)['bracket_method'],'atr_frozen_v7')
            self.assertAlmostEqual(stop,entry*(1-p['risk_atr_pct']*p['sl_atr']))
            self.assertAlmostEqual(target,entry*(1+p['risk_atr_pct']*p['tp_atr']))
        finally:db.close()

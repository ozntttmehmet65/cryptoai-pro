# CryptoAI Pro V7.5 — BOS / CHoCH TP–SL entegrasyon paketi

**Hedef depo:** `ozntttmehmet65/cryptoai-pro`, başlangıç sürümü: `main` / `745b12fefc424e0066657512ec77ae949bc9ff39` (V7.4).

**Önemli:** Bu arşiv **henüz GitHub'a yüklenmedi veya Render'da yayınlanmadı**. GitHub bağlantısında yeni dal oluşturma isteği `403 Resource not accessible by integration` hatası verdi. Dolayısıyla canlı V7.4 değişmedi. Bu dosyalar mevcut deponun üzerine kurulmak üzere hazırlanmış bir uygulama paketidir.

## Yapılan değişiklikler

- `source/market_structure.py`: İki mum sağda/iki solda **kapanışla doğrulanan** 15 dk swing pivotlarını bulur. Kapanmış mumun son onaylı swing'i kırması BOS (devam) veya CHoCH (yön değişimi) olayı üretir; yalnızca kapanmış mumlar kullanılır.
- Sinyal yönüyle eşleşen son 8 mumdaki yapı kırılımı için korunan swing seviyesinin 0,15 ATR ötesinden SL ve kırılan aralığın 0,618 projeksiyonuyla, en az 1,6R sağlayan TP çıkarılır. SL aralığı 0,6–3,0 ATR, TP mesafesi en çok 6 ATR olmalıdır. Koşul geçmezse, **önceden eğitilmiş ATR planına geri dönülür**. Bu güvenli ve sınırlı geçiş, yalnızca simülasyonda kullanılır; gerçek emir verilmez.
- `source/coin_models.py`: Güncel yapı bilgisini ve tahmini TP/SL'yi tahmin cevabına ekler. Modelin ATR tabanlı kalibrasyonunu, eğitilmiş ağırlıkları, eşikleri ve izinlerini değiştirmez.
- `source/execution_paper.py`: Sanal pozisyon için **gerçek gözlenen alış/satış giriş fiyatıyla** yapısal TP/SL'yi yeniden hesaplar, pozisyon açılırken dondurur. ATR karşılaştırma seviyeleri `entry_audit` alanında saklanır. Sonuçlar `bracket_summary` içinde ATR ve BOS/CHoCH olarak ayrı raporlanır.
- `source/quality_report.py`: 24 saatlik ATR model kalibrasyonuna deneysel BOS/CHoCH işlemlerini dahil etmez; kaç kaydın hariç tutulduğunu açıkça gösterir.
- `source/app.py`, `source/static/app.js`: Fırsat kartı, detay ve sanal işlemler raporunda yöntemi ve deneysel olma durumunu açıklar.
- `tests/test_market_structure.py`: Pivot/yapı, olumsuz senaryolar, sanal giriş ve kalibrasyon ayrımı regresyon testlerini ekler.

### Sonuçları yorumlama

BOS/CHoCH seviyeleri **henüz bağımsız kronolojik holdout ile test edilmemiştir**; mevcut AI'nın ATR TP'sine ait tarihsel oranları, yeni yapı TP'sinin başarı olasılığı değildir. Güncelleme sihirli biçimde işlem sinyalini artırmaz. Eski açık sanal işlemlerin TP/SL'si değiştirilmez. Şema değişikliği ve gerçek emir yoktur.

## Uygulama / test

Giriş hesabında GitHub uygulamasına ilgili depoda **Contents: Read and write** ve dal/PR işlemleri için uygun izin verildiğinde, değişiklikler yeni bir dalda uygulanmalıdır.

Mevcut V7.4 deposu bilgisayarda veya GitHub Codespaces'te açıkken, bu arşivi herhangi bir klasöre açın. Depo kök klasöründe:

```bash
git switch -c v75-bos-choch-risk
python /arşivi-açtığınız-klasör/apply.py
PYTHONPATH=source python -m unittest discover -s tests -p 'test_*.py' -v
node --check source/static/app.js
git diff --check
git diff --stat
```

Testler geçmeden `main`'e aktarmayın. Tüm testler ve kod incelemesi sonrası dalı GitHub'a gönderin, PR açın ve birleştirin. Render hizmeti `cryptoai-pro`, `main` dalı ve Dockerfile üzerinden çalışıyor; **otomatik yayınlama kapalı**. PR birleştirildikten sonra Render `Deploy latest commit` işlemi ayrıca başlatılmalı; tamamlanınca `/api/health`, `/api/paper` ve site arayüzü doğrulanmalıdır.

**Not:** Paket hazırlığı sırasında `confirmed_structure` için 4 sentetik yapısal test çalıştırıldı. Tam depo regresyon/integrasyon testleri bu ortamda GitHub yazma yetkisi ve çalışma kopyası bulunmadığı için çalıştırılamadı.

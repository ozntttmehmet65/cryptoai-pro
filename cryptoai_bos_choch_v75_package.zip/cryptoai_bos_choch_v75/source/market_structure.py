"""Causal confirmed swing breaks (BOS/CHoCH) for forward-looking risk *plans*.

A pivot with two candles on either side is usable only when the two right
candles have CLOSED. Breaks require a candle CLOSE past a confirmed pivot.
No future candles are inspected at an historical decision index.

These levels are not the ATR-bracket labels on which the coin AI was trained.
A structure bracket is experimental, and is never an AI approval condition.
"""
from __future__ import annotations
import math

PIVOT_LEFT = 2
PIVOT_RIGHT = 2
MAX_EVENT_AGE = 8


def confirmed_structure(frame):
    """Return the latest known structural break using only completed 15m bars."""
    empty = {'event': None, 'direction': None, 'bars_since': None,
             'broken_level': None, 'protected_swing': None, 'swing_range': None,
             'event_candle_time': None, 'last_swing_high': None,
             'last_swing_low': None, 'causal': True}
    try:
        if hasattr(frame, 'itertuples'):
            rows = list(frame[['time', 'high', 'low', 'close']].itertuples(index=False, name=None))
        else:
            rows = [(r['time'], r['high'], r['low'], r['close']) for r in frame]
        if len(rows) < 10:
            return empty
        t = [int(r[0]) for r in rows]
        h, l, c = [[float(r[j]) for r in rows] for j in (1, 2, 3)]
        if (any(not math.isfinite(v) or v <= 0 for values in (h, l, c) for v in values)
                or any(l[i] > c[i] or h[i] < c[i] or l[i] > h[i] for i in range(len(c)))
                or any(b - a != 900000 for a, b in zip(t, t[1:]))):
            return empty
    except (TypeError, KeyError, ValueError, OverflowError, IndexError):
        return empty
    swing_hi = swing_lo = None
    trend = 0
    last_event = None
    for i in range(PIVOT_LEFT + PIVOT_RIGHT, len(rows)):
        j = i - PIVOT_RIGHT
        hi_neighbors = h[j-PIVOT_LEFT:j] + h[j+1:j+PIVOT_RIGHT+1]
        lo_neighbors = l[j-PIVOT_LEFT:j] + l[j+1:j+PIVOT_RIGHT+1]
        if h[j] > max(hi_neighbors):
            swing_hi = h[j]
        if l[j] < min(lo_neighbors):
            swing_lo = l[j]
        # A broken pivot is not enough; require both opposing protective swing
        # and a *new close crossing* the level (not repeated events every bar).
        broke_up = (swing_hi is not None and swing_lo is not None and
                    swing_lo < swing_hi and c[i-1] <= swing_hi < c[i])
        broke_down = (swing_hi is not None and swing_lo is not None and
                      swing_lo < swing_hi and c[i] < swing_lo <= c[i-1])
        if broke_up and not broke_down:
            last_event = (i, 'CHoCH' if trend == -1 else 'BOS', 'LONG',
                          swing_hi, swing_lo, swing_hi - swing_lo, t[i])
            trend = 1
        elif broke_down and not broke_up:
            last_event = (i, 'CHoCH' if trend == 1 else 'BOS', 'SHORT',
                          swing_lo, swing_hi, swing_hi - swing_lo, t[i])
            trend = -1
    out = dict(empty, last_swing_high=swing_hi, last_swing_low=swing_lo)
    if last_event:
        i, event, side, level, protection, width, stamp = last_event
        out.update(event=event, direction=side, bars_since=len(rows)-1-i,
                   broken_level=level, protected_swing=protection,
                   swing_range=width, event_candle_time=stamp)
    return out


def structure_bracket(structure, side, entry, atr_pct):
    """Experimental swing-anchored stop + break-range-projected target.

    Returns None whenever market structure is absent, stale or unsafe. The
    caller should then use its prevalidated frozen ATR bracket unmodified.
    """
    if not isinstance(structure, dict) or side not in ('LONG', 'SHORT'):
        return None
    if structure.get('event') not in ('BOS', 'CHoCH') or structure.get('direction') != side:
        return None
    age = structure.get('bars_since')
    if not isinstance(age, int) or isinstance(age, bool) or not 0 <= age <= MAX_EVENT_AGE:
        return None
    try:
        entry, atr_pct = float(entry), float(atr_pct)
        level = float(structure['broken_level'])
        protection = float(structure['protected_swing'])
        width = float(structure['swing_range'])
        if not all(math.isfinite(x) and x > 0 for x in (entry, atr_pct, level, protection, width)):
            return None
        if not 0 < atr_pct < .30:
            return None
        atr = entry * atr_pct
        sign = 1 if side == 'LONG' else -1
        if sign * (level - protection) <= 0:
            return None
        stop = protection - sign * .15 * atr
        risk = sign * (entry - stop)
        if not .60 * atr <= risk <= 3.0 * atr or stop <= 0:
            return None
        # A Fibonacci range projection is only one possible target candidate;
        # 1.6R is the minimum to avoid a favorable-looking but tiny TP.
        projection = level + sign * .618 * width
        reward = max(sign * (projection - entry), 1.60 * risk)
        if reward > 6.0 * atr:
            return None
        target = entry + sign * reward
        if min(stop, target) <= 0 or not all(math.isfinite(v) for v in (stop, target)):
            return None
        return {'stop': stop, 'target': target,
                'method': 'bos_choch_confirmed_live', 'event': structure['event'],
                'bars_since': age, 'risk_reward': reward / risk}
    except (KeyError, ValueError, TypeError, OverflowError, ZeroDivisionError):
        return None

"""Apply audited CryptoAI Pro V7.5 structure risk changes to a V7.4 checkout.

Run from the repository root: python path/to/apply.py
Stops without writing anything if an expected old source fragment is missing.
"""
from pathlib import Path
import sys

ROOT=Path.cwd()
PACK=Path(__file__).resolve().parent


def edit(path, replacements):
    f=ROOT/path
    if not f.is_file():
        raise ValueError(f'Missing repository file: {path}')
    old=f.read_text(encoding='utf-8')
    updated=old
    for before,after in replacements:
        found=updated.count(before)
        if found!=1:
            raise ValueError(f'{path}: expected 1 occurrence, found {found}: {before[:130]!r}')
        updated=updated.replace(before,after,1)
    return f,updated


def apply():
    edits=[]
    edits.append(edit('source/coin_models.py',[
        ("        # labels, holdout returns, and live/paper targets use the SAME bracket.",
         "        # Model labels/holdout remain ATR-specific; structure live paper is separately reported."),
        ("from technical_analysis import setup_arrays, technical_scan\n",
         "from technical_analysis import setup_arrays, technical_scan\nfrom market_structure import confirmed_structure, structure_bracket\n"),
        ("        technical = technical_scan(frame)\n        condition=market_condition(frame)",
         "        technical = technical_scan(frame)\n        structure = confirmed_structure(frame)\n        technical['market_structure'] = structure\n        condition=market_condition(frame)"),
        ("            technical[\"stop_estimate\"] = entry - sign*sl_mult*atr\n            technical[\"target_estimate\"] = entry + sign*tp_mult*atr",
         "            tech_bracket = structure_bracket(structure, technical_direction, entry, float(last['atr_pct']))\n            technical[\"stop_estimate\"] = tech_bracket['stop'] if tech_bracket else entry - sign*sl_mult*atr\n            technical[\"target_estimate\"] = tech_bracket['target'] if tech_bracket else entry + sign*tp_mult*atr\n            technical[\"bracket_method\"] = tech_bracket['method'] if tech_bracket else 'atr_frozen_v7'"),
        ("            technical[\"bracket_note\"] = \"Eğitimde seçilen ATR tabanlı örnek TP/SL; geçmiş holdout sonucu ayrıca denetlenir. Takip adayı işlem sinyali değildir\"",
         "            technical[\"bracket_note\"] = (\"BOS/CHoCH swing seviyesi: henüz geçmişte bağımsız test edilmedi; modelin ATR testi buna uygulanamaz.\"\n                                          if tech_bracket else \"Eğitimde seçilen ATR tabanlı örnek TP/SL; takip adayı işlem sinyali değildir.\")"),
        ("        active_side = signal if signal in ('LONG','SHORT') else candidate\n        tp_mult,sl_mult=_multipliers(active_side)",
         "        active_side = signal if signal in ('LONG','SHORT') else candidate\n        tp_mult,sl_mult=_multipliers(active_side)\n        live_bracket = structure_bracket(structure, active_side, entry, float(last['atr_pct']))"),
        ("                \"stop_estimate\":(entry-sl_mult*atr if signal==\"LONG\" else entry+sl_mult*atr if signal==\"SHORT\" else None),\n                \"target_estimate\":(entry+tp_mult*atr if signal==\"LONG\" else entry-tp_mult*atr if signal==\"SHORT\" else None),",
         "                \"stop_estimate\":((live_bracket['stop'] if live_bracket else entry-(1 if signal=='LONG' else -1)*sl_mult*atr) if signal in ('LONG','SHORT') else None),\n                \"target_estimate\":((live_bracket['target'] if live_bracket else entry+(1 if signal=='LONG' else -1)*tp_mult*atr) if signal in ('LONG','SHORT') else None),\n                \"risk_bracket_method\":live_bracket['method'] if live_bracket else 'atr_frozen_v7',\n                \"market_structure\":structure,"),
    ]))
    edits.append(edit('source/execution_paper.py',[
        ("from paper_trade import _bracket\n",
         "from paper_trade import _bracket\nfrom market_structure import structure_bracket\n"),
        ("    bracket=_bracket(side,entry,atr,tp,sl)\n    if bracket is None:return False",
         "    baseline=_bracket(side,entry,atr,tp,sl)\n    if baseline is None:return False\n    structural=structure_bracket(signal.get('market_structure'),side,entry,atr)\n    bracket=(structural['stop'],structural['target']) if structural else baseline\n    audit=dict(signal.get('execution_quality') or {})\n    audit.update(bracket_method='bos_choch_confirmed_live' if structural else 'atr_frozen_v7',\n                 structure_event=structural['event'] if structural else None,\n                 structure_age_bars=structural['bars_since'] if structural else None,\n                 atr_training_baseline_stop=baseline[0],atr_training_baseline_target=baseline[1],\n                 experimental_structure=bool(structural))"),
        ("json.dumps(signal.get('execution_quality') or {},ensure_ascii=False,allow_nan=False)",
         "json.dumps(audit,ensure_ascii=False,allow_nan=False)"),
        ("'funding_return','model_version','regime']",
         "'funding_return','model_version','regime','entry_audit']"),
        ("        r=dict(zip(keys,values));r['settlement_method']=METHOD;r['legacy']=False\n",
         "        r=dict(zip(keys,values));r['settlement_method']=METHOD;r['legacy']=False\n        try:r['bracket_method']=json.loads(r.pop('entry_audit') or '{}').get('bracket_method','atr_frozen_v7')\n        except (ValueError,TypeError,AttributeError):r['bracket_method']='atr_frozen_v7'\n"),
        ("    policies={}\n    for row in approved:",
         "    policies={}\n    brackets={}\n    for row in approved:\n        audit={}"),
        ("        group=policies.setdefault(policy,{'observed':0,'closed':0,'tp':0,'unverified':0})",
         "        method=audit.get('bracket_method','atr_frozen_v7') if isinstance(audit,dict) else 'atr_frozen_v7'\n        if method not in ('atr_frozen_v7','bos_choch_confirmed_live'):method='other'\n        bracket_group=brackets.setdefault(method,{'observed':0,'closed':0,'tp':0,'sl':0,'unverified':0})\n        bracket_group['observed']+=1\n        bracket_group['closed']+=int(row[1]=='CLOSED')\n        bracket_group['tp']+=int(row[1]=='CLOSED' and row[2]=='TP')\n        bracket_group['sl']+=int(row[1]=='CLOSED' and row[2]=='SL')\n        bracket_group['unverified']+=int(row[1]=='VERI_EKSIK')\n        group=policies.setdefault(policy,{'observed':0,'closed':0,'tp':0,'unverified':0})"),
        ("'current_entry_policy':POLICY_VERSION,'entry_policy_summary':policies,",
         "'current_entry_policy':POLICY_VERSION,'entry_policy_summary':policies,\n        'bracket_summary':brackets,'bracket_note':'BOS/CHoCH canlı risk seviyesi deneyseldir; ATR ile eğitilen model TP olasılığı bu seviyeler için doğrulanmamıştır.',"),
    ]))
    edits.append(edit('source/quality_report.py',[
        ("    rows=db.execute('SELECT confidence,observed_at,result_at,exit_reason,state FROM executable_paper WHERE shadow=0').fetchall()\n    resolved=[];censored=unverified=immature=0\n    for score,entry,exit_at,reason,state in rows:",
         "    rows=db.execute('SELECT confidence,observed_at,result_at,exit_reason,state,entry_audit FROM executable_paper WHERE shadow=0').fetchall()\n    resolved=[];censored=unverified=immature=0\n    experimental_excluded=0\n    for score,entry,exit_at,reason,state,audit_text in rows:\n        try:method=json.loads(audit_text or '{}').get('bracket_method','atr_frozen_v7')\n        except (ValueError,TypeError,AttributeError):method='atr_frozen_v7'\n        if method=='bos_choch_confirmed_live':\n            experimental_excluded+=1\n            continue"),
        ("return {'resolved_within_24h':n,'censored_24h':censored,'unverified':unverified,'immature':immature,",
         "return {'resolved_within_24h':n,'censored_24h':censored,'unverified':unverified,'immature':immature,\n        'experimental_structure_excluded':experimental_excluded,"),
        ("'notice':'Onaylı ileri gözlemler; gölge adayları hariç.",
         "'notice':'ATR tabanlı ileri gözlemler; deneysel BOS/CHoCH ve gölge adayları hariç."),
    ]))
    edits.append(edit('source/app.py',[
        ("                     'tp_estimate':combined['tp_estimate'],'sl_estimate':combined['sl_estimate'],",
         "                     'tp_estimate':combined['tp_estimate'],'sl_estimate':combined['sl_estimate'],\n                     'bracket_method':(pred.get('risk_bracket_method') if permitted else (pred.get('technical') or {}).get('bracket_method')),\n                     'market_structure':pred.get('market_structure'),"),
    ]))
    edits.append(edit('source/static/app.js',[
        ("      const history=(item.historical_resolved||0)>0?' · Geçmişte '",
         "      const history=(item.historical_resolved||0)>0?' · ATR modelinin geçmiş testinde '"),
        ("    setText('paperPolicyNote',`${policy} giriş politikasıyla ${v7.observed||0} onaylı gözlem, ${v7.closed||0} kapanmış sonuç. Genel toplamlar önceki giriş politikalarını da içerir; yeni politikanın sonuçları burada ayrı sayılır.`);",
         "    const groups=response.bracket_summary||{},bos=groups.bos_choch_confirmed_live||{},atr=groups.atr_frozen_v7||{};\n    setText('paperPolicyNote',`${policy} giriş politikası: ${v7.observed||0} gözlem, ${v7.closed||0} kapandı. ATR: ${atr.observed||0} (${atr.closed||0} kapandı). Deneysel BOS/CHoCH: ${bos.observed||0} (${bos.closed||0} kapandı; TP: ${bos.tp||0}, SL: ${bos.sl||0}). Bu farklı TP/SL yöntemlerinin sonuçları ayrı incelenmelidir.`);"),
        ("    setText('qualityCalibration',`${c.status||'ÖRNEK AZ'} · 24s içinde çözülen: ${c.resolved_within_24h||0} · Çözülmeyen / geç kapanan: ${c.censored_24h||0} · Veri eksik: ${c.unverified||0} · Henüz 24s dolmayan: ${c.immature||0} · Brier ${n(c.brier,4)} · ECE ${n(c.ece,4)}`);",
         "    setText('qualityCalibration',`${c.status||'ÖRNEK AZ'} · 24s içinde çözülen ATR: ${c.resolved_within_24h||0} · Çözülmeyen / geç kapanan: ${c.censored_24h||0} · Veri eksik: ${c.unverified||0} · Henüz 24s dolmayan: ${c.immature||0} · BOS/CHoCH deneysel, kalibrasyona dahil değil: ${c.experimental_structure_excluded||0} · Brier ${n(c.brier,4)} · ECE ${n(c.ece,4)}`);"),
        ("      card.append(prices);\n      const u=item.unified||{};",
         "      card.append(prices);\n      const method=item.bracket_method==='bos_choch_confirmed_live';\n      const structure=item.market_structure||{};\n      card.append(elem('div',{className:'v60-note'},method?`TP/SL: ${structure.event} (kapanmış mumda teyitli swing kırılımı); deneysel, ATR geçmiş testiyle eşdeğer değildir.`:'TP/SL: eğitimde seçilmiş ATR; güncel uygun BOS/CHoCH seviyesi yok.'));\n      const u=item.unified||{};"),
        ("  setText('entry',price(u.entry_reference));setText('stop',price(u.sl_estimate));setText('target',price(u.tp_estimate));",
         "  const structured=pred?.risk_bracket_method==='bos_choch_confirmed_live';\n  setText('predTechnical',(structured?'BOS/CHoCH TP/SL (deneysel; model olasılığı ATR içindir). ':'ATR TP/SL (eğitimde test edilmiş). ')+$('predTechnical').textContent);\n  setText('entry',price(u.entry_reference));setText('stop',price(u.sl_estimate));setText('target',price(u.tp_estimate));"),
    ]))
    target_src=ROOT/'source/market_structure.py'
    target_test=ROOT/'tests/test_market_structure.py'
    for f in (target_src,target_test):
        if f.exists():raise ValueError(f'Already exists: {f}')
    # Atomic preflight: also check all Python modules compile before writing.
    for f,content in edits:
        if f.suffix == '.py':compile(content,str(f),'exec')
    for f,content in edits:
        f.write_text(content,encoding='utf-8')
        print('UPDATED',f.relative_to(ROOT))
    target_src.write_bytes((PACK/'source/market_structure.py').read_bytes())
    target_test.write_bytes((PACK/'tests/test_market_structure.py').read_bytes())
    print('ADDED',target_src.relative_to(ROOT))
    print('ADDED',target_test.relative_to(ROOT))


if __name__=='__main__':
    try:apply()
    except Exception as exc:
        sys.exit(f'ABORTED (no changes if preflight error): {exc}')
